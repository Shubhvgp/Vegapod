/*
 * MVCU.c
 *
 *  Created on: May 30, 2023
 *      Author: varad
 */

/*
 * This project is designed for a custom STM32F407VGT6 board
 *
 * Peripherals Used:
 * 					CAN1 --> A11 > Rx
 * 							 A12 > Tx
 * 							 Clock for APB1 bus = 42MHZ
 * 							 BAUD Rate = 500k bits/sec
 * 							 prescalar = 6
 * 							 tim_seg_1 = 11
 * 							 tim_seg_2 = 2
 *
 * 					USART2 (USED FOR Serial) --> A3 > Rx
 * 												 A2 > Tx
 *
 * 					USART3 (USED FOR IMU) 	 --> B11 > Rx
 * 											  	 B10 > Tx
 *
 * 					UART4 (USED FOR XBee)	 --> A1 > Rx
 * 											 	 A0 > Tx
 *
 * 					Timer1 -->
 * 					Timer2 -->
 * 					Timer3 -->
 * 					Timer4 -->
 *
 * 					GPIO
 * 						RED_LEDs 	{E1, E3, E5, C13, C15 }
 * 						GREEN_LEDs  {E0, E2, E4,  E6, C14 }
 *
 *	-------------------------------------------------------------------------------------
 *	-------------------------------------------------------------------------------------
 * The system has one MVCU and 5 VCU boards referred as --> BMS_VCU, CLS_VCU, BRAKING_VCU, INVERTER_VCU
 *
 * The base station can send 3 types of command -> a)ARM (b)RUN (c)STOP
 * 		ARM  -> {2,2,2,2,2}
 * 		RUN  -> {1, SinFreq, Amplitude, Direction, param4}
 * 		STOP -> {0,0,0,0,0}
 * 	The mvcu will receive the command from the transceiver at a baud rate of 115200 on UART4 using interrupt
 * 	The received data will be in ASCII values in uint8 array, it will be decoded using function "getDecimal()"
 * 	The decoded data will be then sent to all the VCUs over CAN, to take the respective action.
 * 	The run parameters will go to the inverter VCU which will be -> SinFreq, amplitude, direction
 * 	lookup table for these parameters will be
 * 		1.SinFreq{
 * 			10 > 1
 * 			15 > 2
 * 			20 > 3
 * 			25 > 4
 * 			30 > 5
 * 			35 > 6
 * 			40 > 7
 * 			45 > 8
 * 			50 > 9
 * 		}
 * 		2. amplitude {
 * 			0.25 > 1
 * 			0.50 > 2
 * 			0.60 > 3
 * 			0.70 > 4
 * 			0.75 > 5
 * 			0.80 > 6
 * 			0.85 > 7
 * 			0.90 > 8
 * 			0.95 > 9
 * 		}
 * 		3. direction { 0 = false, 1 = true }

 *
 *
 * All VCUs communicate with the MVCU on CAN at a baud rate of 500k bits per sec, each has a separate CAN_ID
 * 			MVCU		 = 0x103
 * 			BRAKING_VCU  = 0x249	(100ms)
 * 			INVERTER_VCU = 0x302	(110ms)
 * 			BMS_VCU 	 = 0x446	(120ms)
 * 			CLS_VCU 	 = 0x504	(130ms)
 *
 * 	The MVCU transmits a CAN frame to the VCUs only for START/ARM/STOP command, Whereas the VCUs periodically keep transmitting
 * 	data to the MVCU in ARM or RUN state.CAN Frames are of 8 bytes. CAN Frames are defined below --
 * 	i) MVCU to VCUs
 * 	   To get into ARM state  -> [2,2,2,2,2,2,2,2]
 * 	   To get into RUN state  -> [1,SinFreq, Amplitude, Direction, 1,1,1,1]
 * 	   To get into STOP state -> [0,0,0,0,0,0,0,0]
 *	   MVCU sends the CAN frame to the VCU of type uint8 having decimals
 *
 * 	ii) VCU to MVCU
 * 		BRAKING_VCU  -> {SYS_STATE, ERR_BYTE, DATA1, DATA1, ',' , DATA2, DATA2, ','}
 * 		INVERTER_VCU -> {SYS_STATE, ERR_BYTE, DATA1, DATA1, ',' , DATA2, DATA2, ','}
 * 		BMS_VCU		 -> {ERR_BYTE, ID, DATA1, DATA1, ',' , DATA2, DATA2, ','}
 * 		CLS_VCU 	 -> {SYS_STATE, ERR_BYTE, DATA1, DATA1, ',' , DATA2, DATA2, ','}
 * 		VCUs send data to the MVCU of type uint8 but ASCII data
 *
 * 	The MVCU will receive data from the IMU at frequency X, 115200 baud rate using interrupts
 * 	The data from the IMU will be parsed and the critical parameters will be verified for boundary values, & the data will
 * 	be sent to the Base Station.
 *
 */

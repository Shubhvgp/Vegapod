/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "fatfs.h"
#include "fatfs_sd.h"
 #include "ff.h"
 #include <ctype.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

enum ERROR_CODE{
	CAN_ERROR,
	VCU1_ERR,
	VCU2_ERR,
	VCU3_ERR,
	VCU4_ERR,
	VCU5_ERR
};

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define true 1
#define false 0
#define n 10
#define x 55
#define y 485
uint8_t STOP[8] = {0,0,0,0,0,0,0,0};
uint8_t ARM[8] = {2,2,2,2,2,2,2,2};
char ERR_GUI[20];

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

CAN_HandleTypeDef hcan1;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_uart4_rx;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart3_rx;

/* USER CODE BEGIN PV */

uint8_t a = 0;
CAN_RxHeaderTypeDef RxHeader;
CAN_TxHeaderTypeDef TxHeader;
uint32_t TxMailbox;
uint8_t START[8];
uint8_t CAN_DATA_BUFF[8];
uint8_t CAN_BRAKING_DATA[8];
uint8_t CAN_INVERTER_DATA[8];
uint8_t CAN_BMS_DATA[8];
uint8_t CAN_CLS_DATA[8];

uint8_t GUI_CMD_BUFF[n];		//buffer to receive gui commands
uint8_t GUI_CMD[n];				//fin gui commands
uint8_t decimal_GUI_CMD[n]; 	//decimal decoded gui cmd data

uint8_t MVCU_DATA[x-6];			//data array containing all the data
char MVCU_DATA_Tx[x];			//data from mvcu to be transmitted

uint8_t IMU_DATA_BUFF[y];		//IMU data buffer
uint8_t IMU_DATA[y];			//fin
uint8_t IMU_PARAM[y];			//parsed imu data

volatile int SYSTEM_STATE = 0;
volatile int IMU_FLAG = 0;
volatile int CAN_BRAKING_FRAME = 0;
volatile int CAN_INVERTER_FRAME = 0;
volatile int CAN_BMS_FRAME = 0;
volatile int CAN_CLS_FRAME = 0;
volatile int ERROR_FLAG = 0;
volatile int GUI_DEC = 0;
volatile int BRK_ERROR = 0;
volatile int INV_ERROR = 0;
volatile int CLS_ERROR = 0;
volatile int RES = 0;



//imu

#define MAX_FIELDS 500
int var, num_fields = 0;
char msg[500], *fields[MAX_FIELDS];
#define txBuff 500
char txBuffer[txBuff];
char GPGGA[14], GPRMC[20], AOVEL[12], AOATT[16], AOGPS[18], AOSTS[8], AOSEN[18];


//sd card
FATFS fs;  // file system
FIL fil; // file
FILINFO fno;
FRESULT fresult;  // result
UINT br, bw;  // file read/write count
//capacity related
FATFS *pfs;
DWORD fre_clust;
uint32_t total, free_space;
#define BUFFER_SIZE 128
char buffer[BUFFER_SIZE];  // to store strings

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_CAN1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_UART4_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_SPI2_Init(void);
/* USER CODE BEGIN PFP */

void getDecimal(uint8_t arr[]);
void ERROR_FUNCTION(uint8_t error_code);
void XBEE_Callback(uint16_t Size);
void IMU_callback(uint16_t Size);
void display(int error_code);
void vcu_check ();
void decode_message(char *message_str, char **fields, int *num_fields);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){

	if(huart == &huart2){
		XBEE_Callback(Size);
		HAL_UARTEx_ReceiveToIdle_DMA(&huart2, GUI_CMD_BUFF, n);
		__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);
	}
	else if( huart == &huart3){
		IMU_callback(Size);
		HAL_UARTEx_ReceiveToIdle_DMA(&huart2, GUI_CMD_BUFF, n);
		__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);
	}

}

/* FRAME TO BE SENT TO GUI
 * {	SYS_STATE	ERR_STATE	BRK_ERR		INV_ERR		BMS_ERR		CLS_ERR
 */

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan){

	if(HAL_CAN_GetRxMessage(&hcan1, CAN_RX_FIFO0, &RxHeader, CAN_DATA_BUFF) != HAL_OK){
		ERROR_FUNCTION(CAN_ERROR);
	}
	switch(RxHeader.StdId){
	//vcu is sending ascii value itself
	//so it will send 54 for an actual sensor value of 6

		case 0x249: memcpy(CAN_BRAKING_DATA, CAN_DATA_BUFF, 8);
					CAN_BRAKING_FRAME = 1;
					if(CAN_BRAKING_DATA[1] != 48){
						ERROR_FUNCTION(CAN_BRAKING_DATA[1]);
					}
					memcpy(MVCU_DATA+7, CAN_BRAKING_DATA+2, 6);
					break;

		case 0x302:	memcpy(CAN_INVERTER_DATA, CAN_DATA_BUFF, 8);
					CAN_INVERTER_FRAME = 1;
					if(CAN_INVERTER_DATA[1] != 48){
						ERROR_FUNCTION(CAN_INVERTER_DATA[1]);
					}
					memcpy(MVCU_DATA+13, CAN_INVERTER_DATA+2, 6);
					break;

		case 0x446:	memcpy(CAN_BMS_DATA, CAN_DATA_BUFF, 8);
					CAN_BMS_FRAME = 1;
					if(a==3){
						a = 0;
					}
					else{
						a++;
					}
					if(CAN_BMS_DATA[1] != 48){
						ERROR_FUNCTION(CAN_BMS_DATA[1]);
					}
					memcpy(MVCU_DATA+19, CAN_BMS_DATA+1, 7);
					break;

		case 0x504:	memcpy(CAN_CLS_DATA, CAN_DATA_BUFF, 8);
					CAN_CLS_FRAME = 1;
					if(CAN_CLS_DATA[1] != 48){
						ERROR_FUNCTION(CAN_CLS_DATA[1]);
					}
					memcpy(MVCU_DATA+26, CAN_CLS_DATA+2, 6);
					break;

	}

}




void XBEE_Callback(uint16_t Size){

	if(Size == 5){

		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);

		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_4, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
		for(int i = 0; i<Size; i++){
			GUI_CMD[i] = GUI_CMD_BUFF[i] - '0';
		}
		uint8_t SinFreq = GUI_CMD[1];
		uint8_t amp		= GUI_CMD[2];
		uint8_t dir		= GUI_CMD[3];

		switch(GUI_CMD[0]){
			case 0: if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox)!= HAL_OK){
						ERROR_FUNCTION(CAN_ERROR);
					}
					SYSTEM_STATE = 0;
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);

					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_4, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
					break;

			case 1: START[0] = 1;
					START[1] = SinFreq;
					START[2] = amp;
					START[3] = dir;
					if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, START, &TxMailbox)!= HAL_OK){
						ERROR_FUNCTION(CAN_ERROR);
					}
					SYSTEM_STATE = 1;
					break;

			case 2: if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, ARM, &TxMailbox)!= HAL_OK){
						ERROR_FUNCTION(CAN_ERROR);
					}
					SYSTEM_STATE = 2;

					break;

			default: if(HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox)!= HAL_OK){
						ERROR_FUNCTION(CAN_ERROR);
					 }
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_1, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_3, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_15, GPIO_PIN_RESET);

					HAL_GPIO_WritePin(GPIOC, GPIO_PIN_14, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_4, GPIO_PIN_RESET);
					HAL_GPIO_WritePin(GPIOE, GPIO_PIN_6, GPIO_PIN_RESET);
					break;


		}
	}
	else{
		//command not received properly from gui
		HAL_UART_Transmit(&huart4, (uint8_t *)ERR_GUI, 5, HAL_MAX_DELAY);

	}


}

void IMU_callback(uint16_t Size){
	//add if condition to check size

	memcpy(IMU_DATA, IMU_DATA_BUFF, Size);

	//add imu data parsing function
	//
	decode_message((char*)IMU_DATA, fields, &num_fields);
	//
	//
	//

}


void vcu_check(){
	if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_13) != GPIO_PIN_SET){
		ERROR_FUNCTION(VCU1_ERR);
	}
	if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12) != GPIO_PIN_SET){
			ERROR_FUNCTION(VCU2_ERR);
	}
	if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_11) != GPIO_PIN_SET){
			ERROR_FUNCTION(VCU3_ERR);
	}
	if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_10) != GPIO_PIN_SET){
			ERROR_FUNCTION(VCU4_ERR);
	}
	if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_9) != GPIO_PIN_SET){
			ERROR_FUNCTION(VCU5_ERR);
	}
}

void update_data(char* updatedData)
{
//	char* updatedData = "This is updated data";
	fresult = f_open(&fil, "file1.txt", FA_OPEN_EXISTING | FA_READ | FA_WRITE);

	  	// Move to offset to the end of the file
	  	fresult = f_lseek(&fil, f_size(&fil));

	  	//if (fresult == FR_OK)send_uart ("About to update the file1.txt\n");

	  	// write the string to the file
	  	fresult = f_puts(updatedData, &fil);

	  	f_close (&fil);

	  	clear_buffer();
}

void send_uart (char *string)
{
	uint8_t len = strlen (string);
	HAL_UART_Transmit(&huart2, (uint8_t *) string, len, HAL_MAX_DELAY);  // transmit in blocking mode
}

void clear_buffer (void)
{
	for (int i=0; i<BUFFER_SIZE; i++) buffer[i] = '\0';
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	memset(MVCU_DATA_Tx, '0', x);
	MVCU_DATA[0] = SYSTEM_STATE + '0';
	MVCU_DATA[1] = BRK_ERROR + '0';
	MVCU_DATA[2] = INV_ERROR + '0';
	MVCU_DATA[3] = CLS_ERROR + '0';
	MVCU_DATA[4] = 44;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_CAN1_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_UART4_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_SPI2_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */

  HAL_CAN_Start(&hcan1);
  HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

  HAL_UARTEx_ReceiveToIdle_DMA(&huart3, IMU_DATA_BUFF, y);
  __HAL_DMA_DISABLE_IT(&hdma_usart3_rx, DMA_IT_HT);

  HAL_UARTEx_ReceiveToIdle_DMA(&huart2, GUI_CMD_BUFF, y);
   __HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);

  HAL_UARTEx_ReceiveToIdle_DMA(&huart4, GUI_CMD_BUFF, n);
  __HAL_DMA_DISABLE_IT(&hdma_uart4_rx, DMA_IT_HT);

  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_SET);//mvcu hbt

  TxHeader.DLC = 8;
  TxHeader.StdId = 0x103;
  TxHeader.IDE = CAN_ID_STD;
  TxHeader.RTR = CAN_RTR_DATA;
  uint8_t arr[6] ={'s','t', 'a', 'r', 't', 44};
  uint8_t arr1[5]= {'s', 't', 'o', 'p', 44};



  DSTATUS my_status = SD_disk_initialize(0);
       if(my_status == STA_NOINIT ){
//          send_uart ("error in initializing SD CARD.\n");
       }else // send_uart ("SD initializing OK.\n");

       if (my_status == STA_NODISK){
          // send_uart ("No medium in the drive.\n");
       }
       if (my_status == STA_PROTECT){
          // send_uart (" Write protected.\n");
       }

      fresult = f_mount(&fs, "0:", 1);
      	 if (fresult == FR_OK) {
//      	        send_uart("Operation was successful.\n");
      	    } else if (fresult == FR_NO_FILE) {
//      	        send_uart("File not found.\n");
      	    } else if (fresult == FR_INVALID_PARAMETER) {
//      	        send_uart("Invalid parameter.\n");
      	    } else if (fresult == FR_NO_FILESYSTEM){
//      	        send_uart("FILESYSTEM Error occurred\n");
      	    } else {
//      	    	send_uart("UNKNOWN ERROR\n");
      	    }
      // Check free space
      f_getfree("", &fre_clust, &pfs);
      total = (uint32_t)((pfs->n_fatent - 2) * pfs->csize * 0.5);
      //  	sprintf (buffer, "SD CARD Total Size: \t%lu\n",total);
      //  	send_uart(buffer);
      //  	clear_buffer();
        	free_space = (uint32_t)(fre_clust * pfs->csize * 0.5);
      //  	sprintf (buffer, "SD CARD Free Space: \t%lu\n\n",free_space);
      //  	send_uart(buffer);
      //  	clear_buffer();
      // Open file to write/create a file
      	fresult = f_open(&fil, "file1.txt", FA_OPEN_ALWAYS | FA_READ | FA_WRITE);

      // Writing text
      	f_puts("This data is from the FILE1.txt. IT CONTAINS IMU DATA\n", &fil);

      // Close file
   	  	f_close(&fil);
  //    	update_data();
   	  	clear_buffer();

   	// Close file
  //    	fresult = f_close(&fil);
  //	  decode_msg(input, fields, &num_fields);




  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox);
	 //if(CAN_BMS_FRAME && CAN_BRAKING_FRAME && CAN_INVERTER_FRAME && CAN_CLS_FRAME){
	 if( CAN_BRAKING_FRAME /*&& CAN_INVERTER_FRAME*/ ){
		 //send data to xbee
		 sprintf(MVCU_DATA_Tx, "%s\n", MVCU_DATA);
		 HAL_UART_Transmit(&huart2, (uint8_t *)MVCU_DATA_Tx, sizeof(MVCU_DATA_Tx), HAL_MAX_DELAY);
		 CAN_BMS_FRAME = 0;
		 CAN_BRAKING_FRAME = 0;
		 CAN_CLS_FRAME = 0;
		 CAN_INVERTER_FRAME = 0;

	 }
	 //HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox);
	 //HAL_UART_Transmit(&huart2, (uint8_t *)arr, sizeof(arr), HAL_MAX_DELAY);
	 while(SYSTEM_STATE == 2){
			HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_5);
			HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_3);
			HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_1);
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
			if( CAN_BRAKING_FRAME /*&& CAN_INVERTER_FRAME*/ ){
				 //send data to xbee
				 sprintf(MVCU_DATA_Tx, "%s\n", MVCU_DATA);
				 HAL_UART_Transmit(&huart2, (uint8_t *)arr, sizeof(arr), HAL_MAX_DELAY);
				 HAL_UART_Transmit(&huart2, (uint8_t *)MVCU_DATA_Tx, sizeof(MVCU_DATA_Tx), HAL_MAX_DELAY);
				 HAL_UART_Transmit(&huart2, (uint8_t *)arr1, sizeof(arr1), HAL_MAX_DELAY);
				 CAN_BMS_FRAME = 0;
				 CAN_BRAKING_FRAME = 0;
				 CAN_CLS_FRAME = 0;
				 CAN_INVERTER_FRAME = 0;
			}

			HAL_Delay(750);
	 }
	 while(SYSTEM_STATE == 1){
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_0);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_2);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_4);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_6);
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_14);

		if( CAN_BRAKING_FRAME /*&& CAN_INVERTER_FRAME*/ ){
			 //send data to xbee
			 sprintf(MVCU_DATA_Tx, "%s\n", MVCU_DATA);
			 HAL_UART_Transmit(&huart2, (uint8_t *)arr, sizeof(arr), HAL_MAX_DELAY);
			 HAL_UART_Transmit(&huart2, (uint8_t *)MVCU_DATA_Tx, sizeof(MVCU_DATA_Tx), HAL_MAX_DELAY);
			 HAL_UART_Transmit(&huart2, (uint8_t *)arr1, sizeof(arr1), HAL_MAX_DELAY);
			 update_data(MVCU_DATA_Tx);
			 CAN_BMS_FRAME = 0;
			 CAN_BRAKING_FRAME = 0;
			 CAN_CLS_FRAME = 0;
			 CAN_INVERTER_FRAME = 0;
		}

		HAL_Delay(100);
	 }
	 //vcu_check();
	 HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_5);
	 HAL_Delay(50);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 10;
  RCC_OscInitStruct.PLL.PLLN = 210;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 6;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_11TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

    CAN_FilterTypeDef CAN_Filter;

    CAN_Filter.FilterActivation = CAN_FILTER_ENABLE;
    CAN_Filter.FilterBank  = 10;
    CAN_Filter.FilterFIFOAssignment = CAN_RX_FIFO0;
    CAN_Filter.FilterIdHigh = 0x0000;
	//CAN_Filter.FilterIdHigh = 0x103<<5;
    CAN_Filter.FilterIdLow = 0x0000;
    CAN_Filter.FilterMaskIdHigh = 0X0000;
	//CAN_Filter.FilterMaskIdHigh = 0x103<<5;
    CAN_Filter.FilterMaskIdLow = 0x0000;
    CAN_Filter.FilterMode = CAN_FILTERMODE_IDMASK;
    CAN_Filter.FilterScale = CAN_FILTERSCALE_32BIT;

	if( HAL_CAN_ConfigFilter(&hcan1,&CAN_Filter) != HAL_OK)
	{
		Error_Handler();
	}

  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_OC_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_OC_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 0;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 4294967295;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_OC_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_OC_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 0;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 65535;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_OC_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_TIMING;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_OC_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
  /* DMA1_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream2_IRQn);
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_0|GPIO_PIN_1, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(MVCU_HBT_GPIO_Port, MVCU_HBT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE2 PE3 PE4 PE5
                           PE6 PE0 PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PC13 PC14 PC15 */
  GPIO_InitStruct.Pin = GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : VCU_5_HBT_Pin VCU_4_HBT_Pin VCU_3_HBT_Pin VCU_2_HBT_Pin
                           VCU_1_HBT_Pin */
  GPIO_InitStruct.Pin = VCU_5_HBT_Pin|VCU_4_HBT_Pin|VCU_3_HBT_Pin|VCU_2_HBT_Pin
                          |VCU_1_HBT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : MVCU_HBT_Pin */
  GPIO_InitStruct.Pin = MVCU_HBT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(MVCU_HBT_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */


void getDecimal(uint8_t arr[]){

	for(int i = 0; i<8; i++){

		decimal_GUI_CMD[i] = arr[i] - '0';

	}
	GUI_DEC = 1;

}

void ERROR_FUNCTION(uint8_t error_code){


	char msg[30];
	sprintf(msg,"Error:%d", error_code);
	HAL_UART_Transmit(&huart4, (uint8_t*)MVCU_DATA_Tx, sizeof(MVCU_DATA_Tx), HAL_MAX_DELAY);

	HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox);
	 __disable_irq();
	while(1){
		HAL_CAN_AddTxMessage(&hcan1, &TxHeader, STOP, &TxMailbox);
		HAL_UART_Transmit(&huart4, (uint8_t *)msg, sizeof(msg), HAL_MAX_DELAY);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_1);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_3);
		HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_5);
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
		HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_15);
		HAL_Delay(250);
	}
}




char *separate_values(char *str)
{
    char *token;
    if ((token = strtok(str, "*")) != NULL)
    {
        return token;
    }
    return NULL;
}

//14,

void decode_message(char *message_str, char **fields, int *num_fields)
{
    //sprintf(msg, "\n%s", message_str);
    //HAL_UART_Transmit(&huart1, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
    char *field = strtok(message_str, ",");
    while (field != NULL)
    {
        fields[(*num_fields)++] = field;
        field = strtok(NULL, ",");
    }

    //$GPGGA
    /*sprintf(txBuffer,"\nUTC time: %s\nLatitude: %s %s\nLongitude: %s %s\nAltitude: %s %s\n\n"
    		, fields[1], fields[2], fields[3], fields[4], fields[5], fields[9], fields[10]);*/


    /*sprintf(GPGGA, "%s,%s,%s,%s,%s,%s,%s,", fields[1], fields[2], fields[3], fields[4], fields[5], fields[9], fields[10]);
    memcpy(MVCU_DATA+30, GPGGA, 14);*/

    //$GPRMC
    /*sprintf(txBuffer,"UTC time: %s\nFixData: %s\nLatitude: %s %s\nLongitude: %s %s\nSpeed in Knots: %s\nCourse: %s\nDate: %s\nMagnetic variation: %s\n"
    	    , fields[12], fields[13], fields[14], fields[15], fields[16], fields[17], fields[18], fields[19], fields[20], fields[21]);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    /*sprintf(GPRMC, "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,", fields[12], fields[13], fields[14], fields[15], fields[16], fields[17], fields[18], fields[19], fields[20], fields[21]);
    memcpy(MVCU_DATA+44, GPRMC, 20);*/


    //$AOVEL
    char *val_29 = separate_values(fields[29]);
    /*sprintf(txBuffer, "\nVx : %s\nVy : %s\nVz : %s\nVn : %s\nVe : %s\nVd : %s\n"
    		, fields[24], fields[25], fields[26], fields[27], fields[28], val_29);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    sprintf(AOVEL, "%s,%s,%s,%s,%s,%s,", fields[24], fields[25], fields[26], fields[27], fields[28], val_29);
//    update_data(AOVEL);
    memcpy(MVCU_DATA+32, AOVEL, 12);


//    //$AOATT
    char *val_37 = separate_values(fields[37]);
    /*sprintf(txBuffer, "\nRoll: %s\nPitch: %s\nHeading: %s\nQuaternion Q0: %s\nQuaternion Q1: %s\nQuaternion Q2: %s\nQuaternion Q3: %s\nInsMode: %s\n",
            fields[30], fields[31], fields[32], fields[33], fields[34], fields[35], fields[36], val_37);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    sprintf(AOATT, "%s,%s,%s,%s,%s,%s,%s,%s,", fields[30], fields[31], fields[32], fields[33], fields[34], fields[35], fields[36], val_37);
//    update_data(AOATT);
    memcpy(MVCU_DATA+44, AOATT, 16);


//    //$AOGPS
    //char *val_46 = separate_values(fields[46]);
    /*sprintf(txBuffer, "\nFix Status: %s\nFix Type: %s\nNumber of satellites: %s\nGPS Latitude: %s\nGPS Longitude: %s\nGPS Altitude: %s\nGPS SOG: %s\nGPS COG: %s\nPDOP (Position Dilution of Precision): %s\n",
            fields[38], fields[39], fields[40], fields[41], fields[42], fields[43], fields[44], fields[45], val_46);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    /*sprintf(AOGPS, "%s,%s,%s,%s,%s,%s,%s,%s,%s,", fields[38], fields[39], fields[40], fields[41], fields[42], fields[43], fields[44], fields[45], val_46);
    memcpy(MVCU_DATA+92, AOGPS, 18);*/


//        //"$AOSTS
    //char *val_50 = separate_values(fields[50]);
    /*sprintf(txBuffer, "\nTime since EPOCH: %s\nMicroseconds since last second: %s\nINS Status: %s\nHardware Status: %s\n",
            fields[47], fields[48], fields[49], val_50);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    /*sprintf(AOSTS, "%s,%s,%s,%s,", fields[47], fields[48], fields[49], val_50);
    memcpy(MVCU_DATA+110, AOSTS, 8);*/

//    //$AOSEN
    char *val_59 = separate_values(fields[59]);
    /*sprintf(txBuffer,"\nAcceleration in X-axis: %s\nAcceleration in Y-axis: %s\nAcceleration in Z-axis: %s\nBody rate in X-axis: %s\nBody rate in Y-axis: %s\nBody rate in Z-axis: %s\nEuler rate while roll(rad/sec): %s\nEuler rate while pitch (rad/sec): %s\nEuler rate while yaw(rad/sec):%s\n",
            fields[51], fields[52], fields[53], fields[54], fields[55], fields[56],fields[57], fields[58], val_59);
    HAL_UART_Transmit(&huart1, (uint8_t *)txBuffer, strlen(txBuffer), HAL_MAX_DELAY);*/

    sprintf(AOSEN, "%s,%s,%s,%s,%s,%s,%s,%s,%s", fields[51], fields[52], fields[53], fields[54], fields[55], fields[56],fields[57], fields[58], val_59);
//    update_data(AOSEN);
    memcpy(MVCU_DATA+60, AOSEN, 18);


    IMU_FLAG = 1;
    //memset(msg, '\0', sizeof(msg));
    //memset(txBuffer, '\0', sizeof(txBuffer));
    memset(message_str, '\0', strlen(message_str));

}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

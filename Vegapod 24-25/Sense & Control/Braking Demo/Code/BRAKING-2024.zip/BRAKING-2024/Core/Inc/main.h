/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define GPIO2_Pin GPIO_PIN_13
#define GPIO2_GPIO_Port GPIOC
#define GPIO1_Pin GPIO_PIN_14
#define GPIO1_GPIO_Port GPIOC
#define LD1_Pin GPIO_PIN_4
#define LD1_GPIO_Port GPIOC
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOC
#define MVCUHBT_Pin GPIO_PIN_10
#define MVCUHBT_GPIO_Port GPIOB
#define LD3_Pin GPIO_PIN_6
#define LD3_GPIO_Port GPIOC
#define LD4_Pin GPIO_PIN_7
#define LD4_GPIO_Port GPIOC
#define LD5_Pin GPIO_PIN_8
#define LD5_GPIO_Port GPIOC
#define LD6_Pin GPIO_PIN_9
#define LD6_GPIO_Port GPIOC
#define VCUHBT_Pin GPIO_PIN_8
#define VCUHBT_GPIO_Port GPIOA
#define GPIO6_Pin GPIO_PIN_12
#define GPIO6_GPIO_Port GPIOC
#define GPIO5_Pin GPIO_PIN_2
#define GPIO5_GPIO_Port GPIOD
#define GPIO4_Pin GPIO_PIN_5
#define GPIO4_GPIO_Port GPIOB
#define GPIO3_Pin GPIO_PIN_6
#define GPIO3_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

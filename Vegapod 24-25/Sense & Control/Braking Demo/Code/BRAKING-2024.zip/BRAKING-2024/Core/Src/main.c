/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

FDCAN_HandleTypeDef hfdcan3;

I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart1;

osThreadId PressureSense1Handle;
osThreadId UARTTransmitHandle;
osThreadId UARTReceiveHandle;
osThreadId HeartbeatHandle;
osThreadId Error_ProtocolHandle;
osThreadId PressureSensor2Handle;
osThreadId PressureSensor3Handle;
osThreadId PressureSensor4Handle;
/* USER CODE BEGIN PV */
//uint8_t RxData[8];
//uint8_t TxData[8];
#define TX_BUFF_SIZE 50

char buffer[TX_BUFF_SIZE];
char RxData[20];
char RxDataU[10];
char TxDataU[64];
float adc_val[4],Vout;
float range = 16.0, v_upper = 4.50, v_lower = 0.50;
float optimal_value, pressure[4];
int flag,count1,count2;
float ADC_VAL[4];

enum ERROR_CODE{
	ALL_GOOD,
	PRESSURE_1_ERROR,
	PRESSURE_2_ERROR,
	PRESSURE_3_ERROR,
	PRESSURE_4_ERROR,
	UARTT_ERROR,
	UARTR_ERROR,
	CAN_ERROR,
	MVCU_ERROR
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_I2C1_Init(void);
static void MX_UART4_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_FDCAN3_Init(void);
void StartPS1(void const * argument);
void UARTT(void const * argument);
void UARTR(void const * argument);
void HBT(void const * argument);
void ERR_PRTCL(void const * argument);
void StartPS2(void const * argument);
void StartPS3(void const * argument);
void StartPS4(void const * argument);

/* USER CODE BEGIN PFP */
void ADC_Select_Channel(uint32_t channel, uint8_t rank);
void getPower(float adc_val);
void getPress(float *adc_vals, int size);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void ERROR_FUNCTION(int error_code){

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_UART4_Init();
  MX_USART1_UART_Init();
  MX_FDCAN3_Init();
  /* USER CODE BEGIN 2 */
  /*HAL_UART_Transmit_IT(&huart4,RxData,strlen(RxData));
  if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) != GPIO_PIN_SET) {
//		ERROR_FUNCTION(MVCU_ERROR);
		HAL_GPIO_WritePin(GPIOC, LD1_Pin|LD2_Pin|LD3_Pin, GPIO_PIN_SET);
  }
  else if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) == GPIO_PIN_SET){
	  HAL_GPIO_WritePin(GPIOA, VCUHBT_Pin, 1);
	  HAL_GPIO_WritePin(GPIOC, LD4_Pin, GPIO_PIN_SET);
	  HAL_Delay(10);
	  HAL_GPIO_WritePin(GPIOC, LD5_Pin, GPIO_PIN_SET);
	  HAL_Delay(10);
	  HAL_GPIO_WritePin(GPIOC, LD6_Pin, GPIO_PIN_SET);
	  HAL_Delay(10);
	  HAL_GPIO_WritePin(GPIOC, LD4_Pin|LD5_Pin|LD6_Pin, GPIO_PIN_RESET);

  }

  HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);

  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET); // signal the precharge board to disengage brakes
  HAL_Delay(500);*/

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of PressureSense1 */
  osThreadDef(PressureSense1, StartPS1, osPriorityLow, 0, 128);
  PressureSense1Handle = osThreadCreate(osThread(PressureSense1), NULL);

  /* definition and creation of UARTTransmit */
  osThreadDef(UARTTransmit, UARTT, osPriorityNormal, 0, 128);
  UARTTransmitHandle = osThreadCreate(osThread(UARTTransmit), NULL);

  /* definition and creation of UARTReceive */
  osThreadDef(UARTReceive, UARTR, osPriorityBelowNormal, 0, 128);
  UARTReceiveHandle = osThreadCreate(osThread(UARTReceive), NULL);

  /* definition and creation of Heartbeat */
  osThreadDef(Heartbeat, HBT, osPriorityNormal, 0, 128);
  HeartbeatHandle = osThreadCreate(osThread(Heartbeat), NULL);

  /* definition and creation of Error_Protocol */
  osThreadDef(Error_Protocol, ERR_PRTCL, osPriorityNormal, 0, 128);
  Error_ProtocolHandle = osThreadCreate(osThread(Error_Protocol), NULL);

  /* definition and creation of PressureSensor2 */
  osThreadDef(PressureSensor2, StartPS2, osPriorityBelowNormal, 0, 128);
  PressureSensor2Handle = osThreadCreate(osThread(PressureSensor2), NULL);

  /* definition and creation of PressureSensor3 */
  osThreadDef(PressureSensor3, StartPS3, osPriorityNormal, 0, 128);
  PressureSensor3Handle = osThreadCreate(osThread(PressureSensor3), NULL);

  /* definition and creation of PressureSensor4 */
  osThreadDef(PressureSensor4, StartPS4, osPriorityAboveNormal, 0, 128);
  PressureSensor4Handle = osThreadCreate(osThread(PressureSensor4), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

//	  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_SET);
	  //	  press_adc1();
	  	 /* HAL_GPIO_TogglePin(GPIOC, LD4_Pin);
	  	  HAL_GPIO_TogglePin(GPIOC, LD5_Pin);
	  	  HAL_GPIO_TogglePin(GPIOC, LD6_Pin);
	  	  HAL_GPIO_TogglePin(GPIOC, LD4_Pin);
	  	  HAL_GPIO_TogglePin(GPIOC, LD5_Pin);
	  	  HAL_GPIO_TogglePin(GPIOC, LD6_Pin);*/
	  	  //FDCAN Transmit Function below to send the value

	  	 /* if (HAL_I2C_Slave_Receive(&hi2c1, RxData, strlen(RxData),100) != HAL_OK) {
	  		          HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_4); // Handle I2C transmission error
	  		      } // Handle I2C transmission error*/


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.GainCompensation = 0;
  hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.NbrOfConversion = 4;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_7;
  sConfig.Rank = ADC_REGULAR_RANK_2;
  sConfig.SamplingTime = ADC_SAMPLETIME_6CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_REGULAR_RANK_3;
  sConfig.SamplingTime = ADC_SAMPLETIME_12CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_9;
  sConfig.Rank = ADC_REGULAR_RANK_4;
  sConfig.SamplingTime = ADC_SAMPLETIME_24CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief FDCAN3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_FDCAN3_Init(void)
{

  /* USER CODE BEGIN FDCAN3_Init 0 */

  /* USER CODE END FDCAN3_Init 0 */

  /* USER CODE BEGIN FDCAN3_Init 1 */

  /* USER CODE END FDCAN3_Init 1 */
  hfdcan3.Instance = FDCAN3;
  hfdcan3.Init.ClockDivider = FDCAN_CLOCK_DIV1;
  hfdcan3.Init.FrameFormat = FDCAN_FRAME_CLASSIC;
  hfdcan3.Init.Mode = FDCAN_MODE_NORMAL;
  hfdcan3.Init.AutoRetransmission = DISABLE;
  hfdcan3.Init.TransmitPause = DISABLE;
  hfdcan3.Init.ProtocolException = DISABLE;
  hfdcan3.Init.NominalPrescaler = 16;
  hfdcan3.Init.NominalSyncJumpWidth = 1;
  hfdcan3.Init.NominalTimeSeg1 = 2;
  hfdcan3.Init.NominalTimeSeg2 = 2;
  hfdcan3.Init.DataPrescaler = 1;
  hfdcan3.Init.DataSyncJumpWidth = 1;
  hfdcan3.Init.DataTimeSeg1 = 1;
  hfdcan3.Init.DataTimeSeg2 = 1;
  hfdcan3.Init.StdFiltersNbr = 0;
  hfdcan3.Init.ExtFiltersNbr = 0;
  hfdcan3.Init.TxFifoQueueMode = FDCAN_TX_FIFO_OPERATION;
  if (HAL_FDCAN_Init(&hfdcan3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN FDCAN3_Init 2 */

  /* USER CODE END FDCAN3_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x40000A0B;
  hi2c1.Init.OwnAddress1 = 108;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart4, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart4, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO2_Pin|GPIO1_Pin|LD1_Pin|LD2_Pin
                          |LD3_Pin|LD4_Pin|LD5_Pin|LD6_Pin
                          |GPIO6_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11|GPIO_PIN_12|GPIO4_Pin|GPIO3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(VCUHBT_GPIO_Port, VCUHBT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIO5_GPIO_Port, GPIO5_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : GPIO2_Pin GPIO1_Pin LD1_Pin LD2_Pin
                           LD3_Pin LD4_Pin LD5_Pin LD6_Pin
                           GPIO6_Pin */
  GPIO_InitStruct.Pin = GPIO2_Pin|GPIO1_Pin|LD1_Pin|LD2_Pin
                          |LD3_Pin|LD4_Pin|LD5_Pin|LD6_Pin
                          |GPIO6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : MVCUHBT_Pin */
  GPIO_InitStruct.Pin = MVCUHBT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(MVCUHBT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB11 PB12 GPIO4_Pin GPIO3_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12|GPIO4_Pin|GPIO3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : VCUHBT_Pin */
  GPIO_InitStruct.Pin = VCUHBT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(VCUHBT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GPIO5_Pin */
  GPIO_InitStruct.Pin = GPIO5_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIO5_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/*void HAL_FDCAN_RxFifo0Callback(FDCAN_HandleTypeDef *hfdcan, uint32_t RxFifo0ITs)
{
  if((RxFifo0ITs & FDCAN_IT_RX_FIFO0_NEW_MESSAGE) != RESET)
  {
     Retrieve Rx messages from RX FIFO0
    if (HAL_FDCAN_GetRxMessage(hfdcan, FDCAN_RX_FIFO0, &RxHeader, RxData) != HAL_OK)
    {
    Error_Handler();
    }

     Display LEDx
    if ((RxHeader.Identifier == 0x321) && (RxHeader.IdType == FDCAN_STANDARD_ID) && (RxHeader.DataLength == FDCAN_DLC_BYTES_5))
    {
//      HAL_GPIO_TogglePin(LD2_GPIO_Port,LD2_Pin);
//      ubKeyNumber = RxData[0];
    }
  }
}
*/
int _write(int file, char *ptr, int len)
{
 (void)file;
 int DataIdx;

 for (DataIdx = 0; DataIdx < len; DataIdx++)
 {
   ITM_SendChar(*ptr++);
 }
 return len;
}


/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartPS1 */
/**
  * @brief  Function implementing the PressureSense1 thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartPS1 */
void StartPS1(void const * argument)
{
  /* USER CODE BEGIN 5 */
	enum ERROR_CODE state;
	ADC_MultiModeTypeDef multimode = {0};
	multimode.Mode = ADC_MODE_INDEPENDENT;
	  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
	  {
	    Error_Handler();
	  }

	  void ADC_Select_CH1 (void) {
		  ADC_ChannelConfTypeDef sConfig = {0};

		  sConfig.Channel = ADC_CHANNEL_6;
		   sConfig.Rank = ADC_REGULAR_RANK_1;
		   sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
		   sConfig.SingleDiff = ADC_SINGLE_ENDED;
		   sConfig.OffsetNumber = ADC_OFFSET_NONE;
		   sConfig.Offset = 0;

		   if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
		   {
		     Error_Handler();
		   }
	  }

  /* Infinite loop */
  for(;;)
  {
	  ADC_Select_CH1();
	  if (HAL_ADC_Start(&hadc1) != HAL_OK)
		  {
		  	  state = PRESSURE_1_ERROR;
		  }
	  HAL_ADC_PollForConversion(&hadc1, 1000);
	  ADC_VAL[0] = HAL_ADC_GetValue(&hadc1);
	  Vout = ADC_VAL[0] * (5.00 / 4095.00); // 4095 = 12-bit resolution
	  pressure[0] = range * ((Vout - v_lower) / (v_upper - v_lower));
	  if (pressure[0] > 12.0 || pressure[0] < 6.0)
	  {
		  state = PRESSURE_1_ERROR;
	  }
	  HAL_ADC_Stop(&hadc1);

	  if (state == PRESSURE_1_ERROR)
	  {
		  sprintf(TxDataU,"start,ERROR,%f,%f,%f,stop",pressure[1],pressure[2],pressure[3]);
	  }
	  else  sprintf(TxDataU,"start,%f,%f,%f,%f,stop",pressure[0],pressure[1],pressure[2],pressure[3]);

	  state = ALL_GOOD;

    osDelay(1);
  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_UARTT */
/**
* @brief Function implementing the UARTTransmit thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_UARTT */
void UARTT(void const * argument)
{
  /* USER CODE BEGIN UARTT */
	enum ERROR_CODE state;
  /* Infinite loop */
  for(;;)
  {
	  if (HAL_UART_Transmit_IT(&huart4, TxDataU, strlen(TxDataU)) != HAL_OK)
	  	 	  {
		  	  	state = UARTT_ERROR;
	  	 		count1++;
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_4);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_4);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_5);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_5);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_6);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_6);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_7);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_7);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_9);
	  	 		osDelay(100);
	  	 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_9);
	  	 		osDelay(100);
	    	  }
    osDelay(1);
  }
  /* USER CODE END UARTT */
}

/* USER CODE BEGIN Header_UARTR */
/**
* @brief Function implementing the UARTReceive thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_UARTR */
void UARTR(void const * argument)
{
  /* USER CODE BEGIN UARTR */
	enum ERROR_CODE state;
  /* Infinite loop */
  for(;;)
  {
	   	 if (HAL_UART_Receive_IT(&huart4, RxDataU, 10) != HAL_OK)
	   	 {
	   		state = UARTR_ERROR;
	   		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_RESET);
	   		count2++;
	   	 }
	  	  	  if (RxDataU == 'Brake')
	  	  	  {
	  	  		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_RESET);
	  	  		  //HAL_Delay(20);
	  	  	  }

	  	  	  else
	  	  	  {
	  	  		  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, GPIO_PIN_SET);
	  	  		  //HAL_Delay(20);
	  	  	  }

    osDelay(1);
  }
  /* USER CODE END UARTR */
}

/* USER CODE BEGIN Header_HBT */
/**
* @brief Function implementing the Heartbeat thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_HBT */
void HBT(void const * argument)
{
  /* USER CODE BEGIN HBT */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END HBT */
}

/* USER CODE BEGIN Header_ERR_PRTCL */
/**
* @brief Function implementing the Error_Protocol thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_ERR_PRTCL */
void ERR_PRTCL(void const * argument)
{
  /* USER CODE BEGIN ERR_PRTCL */
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END ERR_PRTCL */
}

/* USER CODE BEGIN Header_StartPS2 */
/**
* @brief Function implementing the PressureSensor2 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartPS2 */
void StartPS2(void const * argument)
{
  /* USER CODE BEGIN StartPS2 */
	enum ERROR_CODE state;
	ADC_MultiModeTypeDef multimode = {0};
	multimode.Mode = ADC_MODE_INDEPENDENT;

	  void ADC_Select_CH2 (void){
		  ADC_ChannelConfTypeDef sConfig = {0};

		  sConfig.Channel = ADC_CHANNEL_7;
		   sConfig.Rank = ADC_REGULAR_RANK_1;
		   sConfig.SamplingTime = ADC_SAMPLETIME_6CYCLES_5;
		   if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
		   {
		     Error_Handler();
		   }
	  }
  /* Infinite loop */
  for(;;)
  {
	  ADC_Select_CH2();
	  if (HAL_ADC_Start(&hadc1) != HAL_OK)
		  {
		  state = PRESSURE_2_ERROR;
		  }
	  HAL_ADC_PollForConversion(&hadc1, 1000);
	  ADC_VAL[1] = HAL_ADC_GetValue(&hadc1);
	  Vout = ADC_VAL[1] * (5.00 / 4095.00); // 4095 = 12-bit resolution
	  pressure[1] = range * ((Vout - v_lower) / (v_upper - v_lower));
	  if (pressure[0] > 12.0 || pressure[0] < 6.0)
	  {
		  state = PRESSURE_2_ERROR;
	  }
	  HAL_ADC_Stop(&hadc1);

	  if (state == PRESSURE_2_ERROR)
	  {
		  sprintf(TxDataU,"start,%f,ERROR,%f,%f,stop",pressure[0],pressure[2],pressure[3]);
	  }
	  else  sprintf(TxDataU,"start,%f,%f,%f,%f,stop",pressure[0],pressure[1],pressure[2],pressure[3]);

	  state = ALL_GOOD;

    osDelay(1);
  }
  /* USER CODE END StartPS2 */
}

/* USER CODE BEGIN Header_StartPS3 */
/**
* @brief Function implementing the PressureSensor3 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartPS3 */
void StartPS3(void const * argument)
{
  /* USER CODE BEGIN StartPS3 */
	enum ERROR_CODE state;
	ADC_MultiModeTypeDef multimode = {0};
	multimode.Mode = ADC_MODE_INDEPENDENT;

	  void ADC_Select_CH3 (void){
		  ADC_ChannelConfTypeDef sConfig = {0};

		  sConfig.Channel = ADC_CHANNEL_8;
		  sConfig.Rank = ADC_REGULAR_RANK_1;
		  sConfig.SamplingTime = ADC_SAMPLETIME_12CYCLES_5;
		  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
		  {
		    Error_Handler();
		  }
	  }
  /* Infinite loop */
  for(;;)
  {
	  ADC_Select_CH3();
	  if (HAL_ADC_Start(&hadc1) != HAL_OK)
		  {
		  state = PRESSURE_3_ERROR;
		  }
	  HAL_ADC_PollForConversion(&hadc1, 1000);
	  ADC_VAL[2] = HAL_ADC_GetValue(&hadc1);
	  Vout = ADC_VAL[2] * (5.00 / 4095.00); // 4095 = 12-bit resolution
	  pressure[2] = range * ((Vout - v_lower) / (v_upper - v_lower));
	  if (pressure[0] > 8.0 || pressure[0] < 6.0)
	  {
		  state = PRESSURE_3_ERROR;
	  }
	  HAL_ADC_Stop(&hadc1);

	  if (state == PRESSURE_3_ERROR)
	  {
		  sprintf(TxDataU,"start,%f,%f,ERROR,%f,stop",pressure[0],pressure[1],pressure[3]);
	  }
	  else  sprintf(TxDataU,"start,%f,%f,%f,%f,stop",pressure[0],pressure[1],pressure[2],pressure[3]);

	  state = ALL_GOOD;
	  osDelay(1);
  }
  /* USER CODE END StartPS3 */
}

/* USER CODE BEGIN Header_StartPS4 */
/**
* @brief Function implementing the PressureSensor4 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartPS4 */
void StartPS4(void const * argument)
{
  /* USER CODE BEGIN StartPS4 */
	enum ERROR_CODE state;
	ADC_MultiModeTypeDef multimode = {0};
	multimode.Mode = ADC_MODE_INDEPENDENT;

	  void ADC_Select_CH4 (void){
		  ADC_ChannelConfTypeDef sConfig = {0};

		  sConfig.Channel = ADC_CHANNEL_9;
		  sConfig.Rank = ADC_REGULAR_RANK_1;
		  sConfig.SamplingTime = ADC_SAMPLETIME_24CYCLES_5;
		  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
		  {
		    Error_Handler();
		  }
	  }
  /* Infinite loop */
  for(;;)
  {
	  ADC_Select_CH4();
	  if (HAL_ADC_Start(&hadc1) != HAL_OK)
		  {
		  state = PRESSURE_4_ERROR;
		  }
	  HAL_ADC_PollForConversion(&hadc1, 1000);
	  ADC_VAL[3] = HAL_ADC_GetValue(&hadc1);
	  Vout = ADC_VAL[3] * (5.00 / 4095.00); // 4095 = 12-bit resolution
	  pressure[3] = range * ((Vout - v_lower) / (v_upper - v_lower));
	  if (pressure[0] > 8.0 || pressure[0] < 6.0)
	  {
		  state = PRESSURE_4_ERROR;
	  }
	  HAL_ADC_Stop(&hadc1);

	  if (state == PRESSURE_4_ERROR)
	  {
		  sprintf(TxDataU,"start,%f,%f,%f,ERROR,stop",pressure[0],pressure[1],pressure[2]);
	  }
	  else  sprintf(TxDataU,"start,%f,%f,%f,%f,stop",pressure[0],pressure[1],pressure[2],pressure[3]);

	  state = ALL_GOOD;

	  osDelay(1);
  }
  /* USER CODE END StartPS4 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
